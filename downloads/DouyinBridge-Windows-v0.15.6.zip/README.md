# DouyinBridge

## Windows companion: official browser QR login on iPhone 4S

**Why this exists:** When Douyin returns code 4031 or an HTML anti-bot page while generating a QR code, the legacy iOS 8 app has no valid QR token to display. Repeating the same HTTP API call will not fix the server response. A user-visible modern Chromium browser on the owner's Windows computer is a supported alternative. DouyinBridge does not bypass CAPTCHA, login checks or access controls.

1. Download `DouyinBridge-Windows.zip` from the DouyinLite release and extract it. Keep all the files together.
2. On the Windows computer, install Python 3.10 or newer if needed. Double-click `start_windows.cmd`. The first run installs the Python dependencies, Playwright Chromium and the official Cloudflare tunnel client.
3. A visible Chromium browser starts on the computer. Open `https://www.douyin.com/` and use Douyin's genuine login interface; scan its QR using the normal Douyin app on another phone and complete any required verification.
4. Keep the companion window open. It prints a temporary HTTPS `/api/feed` URL and a random private key. On iPhone 4S, open DouyinLite, tap **我的**, then **电脑浏览器扫码登录**. Enter the URL and private key, and choose **连接**.
5. DouyinLite opens a remote browser viewer. The app's homepage can fetch a browser-backed video feed through the configured endpoint when videos are actually available. If the browser encounters an access challenge or unsupported video, the app may still report empty content. **The computer must remain powered on and connected.**

Security and limitations:
- The service listens only on `127.0.0.1` on the computer and uses a random 48-character private key for remote API requests. Cloudflare Quick Tunnel provides temporary public HTTPS; its address changes when the companion restarts.
- Treat the HTTPS address and secret as private. Do not share either publicly. The secret is stored locally in `.bridge-key` and the login browser profile in `profile/`. Never send either directory, cookies, passwords, or SMS codes to anyone.
- Cookies remain inside the computer browser profile, and are **not transferred to the iPhone**. The phone accesses the authorized remote browser and its publicly available video feed.
- The Windows helper needs a functioning internet connection to install its dependencies and connect to Cloudflare. A firewall, captive portal or network policy can block it. This is an optional computer-assisted mode, not offline or stand-alone phone login.
- Remote viewer screenshot functionality is for navigation and human verification. Video access still depends on Douyin's response and compatible media; Cloudflare TLS support on iOS 8 must be checked on the actual phone.

---


A deployable **experimental** companion for DouyinLite on iPhone 4S. It runs a modern, persistent Chromium browser on a Linux VPS and extracts accessible public video metadata from normal page responses.

**Important:** This service does not bypass CAPTCHA or access controls. A real browser session can still be restricted by Douyin, and available media URLs may expire or use unsupported codecs. Successful compilation alone does not establish a working recommendation feed.

## What is included

- Persistent Playwright Chromium profile and interactive browser desktop (local-only noVNC).
- Manual verification when the browser is redirected to a verification page.
- Authorized JSON API with status, refresh and paginated feed.
- H.264 rendition priority and video deduplication.
- Docker Compose with Caddy automatic HTTPS.
- iOS 8 native client integration using an HTTPS endpoint and API token.

## Deploy

On a Linux VPS, install Docker and the Compose plugin. Minimum recommended 2 vCPU, 4 GB RAM. You also need a domain that points to the VPS and accessible TCP ports 80/443.

```bash
cd douyinlite/bridge
cp .env.example .env
# Edit SITE_HOST to your actual domain.
# Generate BRIDGE_KEY with: openssl rand -hex 24
docker compose -f compose.yml up -d --build
docker compose -f compose.yml logs -f bridge
```

Your API endpoint is `https://YOUR_DOMAIN/api/feed`.

## iPhone 4S native remote Chrome (experimental)

The iPhone's iOS 8 WebKit engine cannot render many modern web applications. DouyinLite now has a native remote viewer that renders **JPEG screenshots of the server-side Chromium browser** instead of trying to run Douyin's JavaScript on the phone.

Once the VPS bridge is deployed and the app is configured with the HTTPS `/api/feed` address and `BRIDGE_KEY`, open DouyinLite's source menu → **云端 Chrome · 登录 / 浏览**. You can tap the screenshot to click browser elements, double-tap to zoom, and use the native 上滑 / 下滑 / 后退 / 首页 buttons. You can also open the cloud viewer from the account login screen after configuring the bridge.

The browser desktop is 1280 × 800; the screenshot is refreshed about every two seconds. It supports human QR-code login and some verification screens, but **this is a low-frame-rate remote-control view, not full video streaming**. To play actual Douyin videos smoothly, the separate original AVPlayer video feed still requires accessible H.264 media URLs. Some site challenges can be unsuitable for a remote viewer or require a physical browser.

The remote-screen and input endpoints are protected by the same private Bearer API key as the feed. Don't expose the key or a public unauthenticated browser endpoint: screenshots can contain account information. Server resources and a domain with trusted HTTPS are required. This does **not** run Chromium on the iPhone or remove Douyin's access-control restrictions.

## Log in with your Douyin account

**Login is optional but supported.** Use the remote Chromium window, open the normal Douyin login dialog, and scan its QR code with the Douyin app on a second device. If required, complete SMS or other human verification there. Do not send account passwords, SMS codes, or cookies to DouyinLite or this repository.

The Chrome profile saves the browser session under the persistent `./profile` directory. You can turn off the computer used for initial setup, but the VPS running DouyinBridge must remain online. A saved session may expire, and a login does **not** guarantee video access on a cloud-server IP.

To inspect session state from the phone, choose **检查 DouyinBridge 登录状态** in DouyinLite. The bridge detects whether login-related session cookies exist, but this is a hint rather than proof the account is currently authenticated.

## Complete any required verification normally

On your desktop, connect to the VPS using SSH local port forwarding:

```bash
ssh -L 6080:127.0.0.1:6080 USER@SERVER
```

Open `http://localhost:6080/vnc.html` in a desktop browser. This shows the server's actual Chromium window. If Douyin presents a login QR code or a CAPTCHA challenge, complete the official login or verification process manually in that browser. Do not expose the noVNC service on the public Internet. The persistent browser profile in `./profile` is sensitive; do not commit or share it.

If verification is unavailable or access remains blocked, the bridge reports that state; it cannot force anonymous recommendations to work.

## Confirm actual content first

```bash
curl -H "Authorization: Bearer YOUR_BRIDGE_KEY" https://YOUR_DOMAIN/api/status
curl -H "Authorization: Bearer YOUR_BRIDGE_KEY" https://YOUR_DOMAIN/api/feed
```

The protected `/api/status` response reports `session_cookie_present` (cookie presence only, never the secret value), `manual_verification`, and the video count. A working feed must include actual items in `data`. A status of `verification_required`, `waiting_for_videos`, or an empty `data` array means the source is not ready.

The response is compatible with DouyinLite:
```json
{"data":[{"id":"123","title":"Public video","url":"https://media.example/video.mp4","source":"douyin-bridge"}],"next":"https://YOUR_DOMAIN/api/feed?cursor=12","status":"ready","message":""}
```
This is a schema example, **not a claim that Douyin returned those videos**.

## Configure DouyinLite

On iPhone 4S: open the source menu, choose **连接 DouyinBridge**, enter `https://YOUR_DOMAIN/api/feed` and the `BRIDGE_KEY` from `.env`. The client connects directly over HTTPS, without leaving a home PC on. Ensure the server supports TLS 1.2 and has a trusted certificate.

## Run unit tests

```bash
pip install -r requirements.txt
python -m pytest -q test_app.py
```

The unit tests cover parsing, duplicate removal, HTTPS URL validation and codec preference; actual site access needs a deployed instance and a real browser session.


## Low-bandwidth video preview (experimental)

The remote viewer offers an **播放云端画面** button. DouyinBridge uses ffmpeg to capture the browser desktop and serve 640×400 12fps H.264 Baseline HLS to iOS 8 AVPlayer, keeping legacy WebKit out of the playback path. This preview currently **has no audio**, needs the separately deployed Docker bridge, and must never be interpreted as native Douyin media extraction. It may show verification screens and remote browser navigation. Video streaming consumes CPU/bandwidth and requires ffmpeg. Close the player to stop its encoder.

Stream playback uses a short-lived secret URL, so treat the HLS address as private. Only HTTPS endpoints should be configured on the phone. Test on a physical iPhone 4S before treating performance as verified.


## Remote HLS sound experiment

The server now offers an optional PulseAudio virtual sink named
douyin_capture. The browser's audio can be multiplexed into HLS as AAC,
alongside H.264 Baseline browser-screen video. If the sink is not available,
the server returns a video-only stream and reports audio=false. Actual browser
media access, audible playback, and iPhone 4S performance need real-world tests.

The 90-second idle limit stops an abandoned encoder. The remote browser's
login and access challenges still require normal human completion.

## Public share resolution and media forwarding (0.10.6)

POST /api/resolve reads the normal official public Douyin mobile share page
for a user-supplied HTTPS Douyin link. It cannot bypass a login challenge.
Media links exposed by /api/feed and /api/resolve use temporary unguessable
/api/media/{ticket} URLs on a private bridge deployment. Native iOS 8
players may request the content using GET or HEAD and HTTP byte ranges.
Media requests use standard mobile-browser headers and each redirected
destination must belong to a supported Douyin/CDN domain. Media is relayed
without transcoding. The bridge still requires a server, TLS, and a secret.
Direct mobile-SSR link parsing can work without a bridge when the device
can reach the official public share page.

## 0.10.7 publicly visible Chrome card fallback

If the user-operated Chromium page displays public video cards but network
API responses provide no usable media, DouyinBridge checks up to four unique
video links visible in the page on each feed attempt. Each video must have
public share-page metadata and a reachable media URL to join the feed.
An empty page or required login still produces an explicit empty status.
