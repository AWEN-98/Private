"""DouyinBridge: persistent, user-verifiable public browser session for DouyinLite.

This service does not circumvent CAPTCHA or platform access controls.
It only exposes videos visible in a normally accessible browser session.
"""
from __future__ import annotations

import asyncio
import hmac
import os
import time
from contextlib import asynccontextmanager
from urllib.parse import urlparse

from fastapi import FastAPI, HTTPException, Request, Response
from pydantic import BaseModel, Field
from playwright.async_api import async_playwright
from streamer import CloudStream, playlist_with_ticket, valid_segment
from fastapi.responses import FileResponse, StreamingResponse
import httpx
from urllib.parse import urljoin
from media import MediaRegistry, allowed_media_url, valid_byte_range
from share import MOBILE_UA, MAX_HTML_SIZE, official_link, video_id, mobile_share_url, parse_public_html

KEY = os.environ.get("BRIDGE_KEY", "")
PROFILE_DIR = os.environ.get("BROWSER_PROFILE", "/data/profile")
HEADLESS = os.environ.get("HEADLESS", "false").lower() == "true"
FEED_URL = "https://www.douyin.com/"
MAX_CACHE = 300
VIEWPORT_WIDTH = 1280
VIEWPORT_HEIGHT = 800

def _urls(address):
    if not isinstance(address, dict):
        return []
    candidates = address.get("url_list")
    return candidates if isinstance(candidates, list) else []

def playable_url(video):
    """Select an explicitly compatible H.264 rendition when available."""
    if not isinstance(video, dict):
        return None
    rates = video.get("bit_rate") or video.get("dynamic_video_list") or []
    if not isinstance(rates, list):
        rates = []
    rates = sorted((r for r in rates if isinstance(r, dict)),
                   key=lambda r: r.get("bit_rate") if isinstance(r.get("bit_rate"), int) else 1e12)
    for rate in rates:
        codec = str(rate.get("codec_type", "")).lower()
        if codec and not any(k in codec for k in ("h264", "avc", "264")):
            continue
        if rate.get("is_h265"):
            continue
        for candidate in _urls(rate.get("play_addr") or rate.get("playAddr")):
            if is_https_video(candidate):
                return candidate
    for address in ("play_addr_h264", "playAddrH264", "play_addr_lowbr"):
        for candidate in _urls(video.get(address)):
            if is_https_video(candidate):
                return candidate
    if not video.get("is_h265"):
        for candidate in _urls(video.get("play_addr") or video.get("playAddr")):
            if is_https_video(candidate):
                return candidate
    return None

def is_https_video(value):
    if not isinstance(value, str) or len(value) > 8192:
        return False
    parsed = urlparse(value)
    return parsed.scheme == "https" and bool(parsed.hostname)

def extract_items(payload):
    """Extract public video metadata from nested feed/SSR JSON responses."""
    results = []
    seen = set()
    def walk(node, depth=0):
        if depth > 14 or len(results) >= 80:
            return
        if isinstance(node, list):
            for item in node[:120]:
                walk(item, depth + 1)
        elif isinstance(node, dict):
            video = node.get("video")
            link = playable_url(video)
            if link:
                item_id = str(node.get("aweme_id") or node.get("id") or link)
                if item_id not in seen:
                    seen.add(item_id)
                    title = node.get("desc") or node.get("title") or ""
                    author = node.get("author")
                    if not title and isinstance(author, dict):
                        title = author.get("nickname", "")
                    results.append({
                        "id": item_id[:100],
                        "url": link,
                        "title": str(title or "抖音公开视频")[:180],
                        "source": "douyin-bridge",
                    })
            for value in node.values():
                if isinstance(value, (list, dict)):
                    walk(value, depth + 1)
    walk(payload)
    return results


class BrowserFeed:
    def __init__(self):
        self.playwright = None
        self.context = None
        self.page = None
        self.items = []
        self.ids = set()
        self.public_attempted = set()
        self.status = "starting"
        self.error = None
        self.last_seen = 0.0
        self.lock = asyncio.Lock()
        self.navigation_lock = asyncio.Lock()

    async def start(self):
        self.playwright = await async_playwright().start()
        try:
            self.context = await self.playwright.chromium.launch_persistent_context(
                PROFILE_DIR, headless=HEADLESS, viewport={"width": VIEWPORT_WIDTH, "height": VIEWPORT_HEIGHT},
                locale="zh-CN", accept_downloads=False,
            )
            self.page = self.context.pages[0] if self.context.pages else await self.context.new_page()
            self.page.on("response", self.on_response)
            await self.navigate()
        except Exception as exc:
            self.status = "browser_error"
            self.error = str(exc)[:300]

    async def navigate(self):
        if self.page is None:
            return
        async with self.navigation_lock:
            self.status = "loading"
            try:
                await self.page.goto(FEED_URL, wait_until="domcontentloaded", timeout=35000)
                await self.page.wait_for_timeout(2500)
                await self.check_status()
            except Exception as exc:
                self.status = "browser_error"
                self.error = str(exc)[:250]

    async def check_status(self):
        if self.page is None:
            return
        try:
            title = (await self.page.title()).lower()
            url = self.page.url.lower()
            challenge = ("验证码", "验证中", "captcha", "challenge", "verify")
            if any(word in title or word in url for word in challenge):
                self.status = "verification_required"
            elif self.items:
                self.status = "ready"
            else:
                self.status = "waiting_for_videos"
        except Exception as exc:
            self.status = "browser_error"
            self.error = str(exc)[:250]

    async def on_response(self, response):
        parsed = urlparse(response.url)
        hostname = parsed.hostname or ""
        if not (hostname == "douyin.com" or hostname.endswith(".douyin.com")):
            return
        if not any(part in parsed.path for part in ("/aweme/", "/feed/", "/video/")):
            return
        if "json" not in response.headers.get("content-type", "").lower():
            return
        try:
            if int(response.headers.get("content-length", "0")) > 4_000_000:
                return
            value = await response.json()
            new_items = extract_items(value)
            if not new_items:
                return
            async with self.lock:
                for item in new_items:
                    if item["id"] not in self.ids and len(self.items) < MAX_CACHE:
                        self.ids.add(item["id"])
                        self.items.append(item)
                self.last_seen = time.time()
                self.status = "ready"
                self.error = None
        except Exception:
            pass

    async def discover_public_cards(self):
        """Fallback: follow ordinary public video links displayed by Chromium.

        This does not invent feed entries; each item must have a publicly
        readable official share page with a real playable video address.
        """
        if not self.page or not self.context:
            return 0
        try:
            links = await self.page.locator("a[href]").evaluate_all(
                "(nodes) => nodes.slice(0,100).map(node => node.href).filter(url => "
                "url && (/\\/video\\/|modal_id=|aweme_id=/.test(url))).slice(0,40)")
        except Exception:
            return 0
        if not isinstance(links, list):
            return 0
        candidates = []
        for link in [self.page.url] + links:
            found = video_id(link) if isinstance(link, str) else None
            if not found or found in self.ids or found in self.public_attempted:
                continue
            self.public_attempted.add(found)
            candidates.append(found)
            if len(candidates) >= 4:
                break

        async def check(found):
            try:
                response = await self.context.request.get(
                    mobile_share_url(found),
                    headers={"User-Agent": MOBILE_UA,
                             "Referer": "https://www.douyin.com/"},
                    timeout=6000, max_redirects=5)
                if response.status != 200:
                    return None
                body = await response.body()
                if len(body) > MAX_HTML_SIZE:
                    return None
                clip = parse_public_html(body.decode("utf-8", errors="replace"))
                if not clip:
                    return None
                return {"id": found, "title": clip["title"],
                        "url": clip["url"], "source": "douyin-public-card"}
            except Exception:
                return None

        found_items = await asyncio.gather(*(check(id_) for id_ in candidates))
        added = 0
        async with self.lock:
            for item in found_items:
                if not item or item["id"] in self.ids or len(self.items) >= MAX_CACHE:
                    continue
                self.ids.add(item["id"])
                self.items.append(item)
                added += 1
            if added:
                self.last_seen = time.time()
                self.status = "ready"
                self.error = None
        return added

    async def ensure_items(self, minimum):
        if not self.page or self.status == "browser_error":
            return
        await self.check_status()
        if self.status == "verification_required":
            return
        if len(self.items) >= minimum:
            return
        async with self.navigation_lock:
            for _ in range(4):
                if len(self.items) >= minimum or len(self.items) >= MAX_CACHE:
                    break
                try:
                    await self.page.mouse.wheel(0, 850)
                    await self.page.keyboard.press("ArrowDown")
                    await self.page.wait_for_timeout(1200)
                    await self.check_status()
                    if self.status == "verification_required":
                        break
                except Exception as exc:
                    self.error = str(exc)[:250]
                    break
        if len(self.items) < minimum and self.status != "verification_required":
            await self.discover_public_cards()

    async def session_info(self):
        """Report cookie presence without disclosing credentials or claiming login validity."""
        cookie_names = {"sessionid", "sessionid_ss", "sid_tt", "sid_guard"}
        result = {"session_cookie_present": False, "login_verified": False}
        if not self.context:
            return result
        try:
            cookies = await self.context.cookies(FEED_URL)
            result["session_cookie_present"] = any(
                item.get("name", "").lower() in cookie_names and bool(item.get("value"))
                for item in cookies
            )
        except Exception:
            pass
        return result

    async def close(self):
        if self.context:
            await self.context.close()
        if self.playwright:
            await self.playwright.stop()


engine = BrowserFeed()
cloud_stream = CloudStream()
media_registry = MediaRegistry()

def media_link(request, original):
    # M3U8 playlists contain relative segment links and must be kept intact.
    if urlparse(original).path.lower().endswith('.m3u8'):
        return original
    token = media_registry.add(original)
    return str(request.url_for('media_proxy', ticket=token)) if token else original

@asynccontextmanager
async def lifespan(app):
    if not KEY or len(KEY) < 16:
        raise RuntimeError("Set BRIDGE_KEY to a random secret of at least 16 characters")
    await engine.start()
    yield
    await cloud_stream.close()
    await engine.close()

app = FastAPI(title="DouyinBridge", lifespan=lifespan, docs_url=None, redoc_url=None)

def authorize(request: Request):
    supplied = request.headers.get("authorization", "")
    expected = "Bearer " + KEY
    if not KEY or not hmac.compare_digest(supplied, expected):
        raise HTTPException(status_code=401, detail="Invalid bridge token")

@app.get("/health")
async def health():
    return {"ok": True}

@app.get("/api/status")
async def status(request: Request):
    authorize(request)
    await engine.check_status()
    session = await engine.session_info()
    return {
        "status": engine.status, "items": len(engine.items),
        "last_seen": int(engine.last_seen), "error": engine.error,
        "manual_verification": engine.status == "verification_required",
        **session,
        "login_help": "Use the private noVNC browser desktop to log in or complete verification manually. A cookie does not guarantee a valid account session.",
    }

@app.get("/api/feed")
async def feed(request: Request, cursor: int = 0):
    authorize(request)
    if cursor < 0 or cursor >= MAX_CACHE:
        raise HTTPException(status_code=400, detail="Invalid cursor")
    await engine.ensure_items(cursor + 12)
    items = engine.items[cursor:cursor + 12]
    safe_items = [{**item, "url": media_link(request, item["url"])} for item in items]
    next_cursor = cursor + len(items)
    next_url = (str(request.url_for("feed")) + "?cursor=" + str(next_cursor)) if items and next_cursor < MAX_CACHE else None
    return {
        "data": safe_items, "next": next_url,
        "status": engine.status, "message": engine.error or (
            "请在云端浏览器正常完成人工验证" if engine.status == "verification_required"
            else "暂无可访问的视频，请检查浏览器页面" if not items else ""
        ),
    }


class PublicShareRequest(BaseModel):
    url: str = Field(min_length=12, max_length=2048)


@app.post("/api/resolve")
async def resolve_public_share(request: Request, value: PublicShareRequest):
    """Use publicly returned metadata for user-submitted official share pages."""
    authorize(request)
    if not official_link(value.url):
        raise HTTPException(status_code=400, detail="仅支持抖音官方 HTTPS 分享链接")
    if engine.context is None:
        raise HTTPException(status_code=503, detail="云端浏览器尚未启动")
    item_id = video_id(value.url)
    queue = [value.url]
    seen = set()
    while queue and len(seen) < 3:
        link = queue.pop(0)
        if link in seen:
            continue
        seen.add(link)
        try:
            response = await engine.context.request.get(
                link,
                headers={"User-Agent": MOBILE_UA, "Referer": "https://www.douyin.com/"},
                timeout=15000, max_redirects=7)
        except Exception:
            continue
        if not item_id and official_link(response.url):
            item_id = video_id(response.url)
        if response.status == 200:
            content = await response.body()
            if len(content) <= MAX_HTML_SIZE:
                clip = parse_public_html(content.decode("utf-8", errors="replace"))
                if clip:
                    return {**clip, "url": media_link(request, clip["url"])}
        if item_id:
            mobile = mobile_share_url(item_id)
            if mobile not in seen and mobile not in queue:
                queue.append(mobile)
    raise HTTPException(status_code=422, detail=(
        "公开分享页未提供可播放的视频数据。可能需要登录验证，或该视频已失效、当前地区无法访问。"))


@app.api_route("/api/media/{ticket}", methods=["GET", "HEAD"], name="media_proxy")
async def media_proxy(ticket: str, request: Request):
    """Serve eligible, previously obtained public media with Range support.

    Random capability URLs allow native AVPlayer to access the media without
    storing a Bearer API key in movie-player configuration. URLs expire.
    """
    source = media_registry.get(ticket)
    if not source:
        raise HTTPException(status_code=404, detail="视频链接已过期，请重新加载")
    user_range = request.headers.get("range")
    if not valid_byte_range(user_range):
        raise HTTPException(status_code=416, detail="Unsupported Range")
    headers = {
        "User-Agent": MOBILE_UA,
        "Referer": "https://www.douyin.com/",
        "Accept": "*/*",
        "Accept-Encoding": "identity",
    }
    if user_range:
        headers["Range"] = user_range
    client = httpx.AsyncClient(timeout=httpx.Timeout(25.0, connect=10.0),
                               follow_redirects=False)
    upstream = None
    current = source
    try:
        for _ in range(6):
            if not allowed_media_url(current):
                raise HTTPException(status_code=502, detail="视频 CDN 地址不受支持")
            req = client.build_request(request.method, current, headers=headers)
            upstream = await client.send(req, stream=True)
            if upstream.status_code not in (301, 302, 303, 307, 308):
                break
            location = upstream.headers.get("location")
            await upstream.aclose()
            upstream = None
            if not location:
                raise HTTPException(status_code=502, detail="CDN 跳转地址为空")
            current = urljoin(current, location)
        else:
            raise HTTPException(status_code=502, detail="CDN 重定向次数过多")

        if upstream.status_code not in (200, 206, 416):
            raise HTTPException(status_code=502, detail=(
                "媒体请求失败（CDN HTTP %d），视频可能已失效" % upstream.status_code))
        out_headers = {"Cache-Control": "private, no-store", "Accept-Ranges": "bytes"}
        for key in ("content-range", "content-length", "etag", "last-modified"):
            if key in upstream.headers:
                out_headers[key] = upstream.headers[key]
        mime = upstream.headers.get("content-type") or "video/mp4"
        if request.method == "HEAD":
            status = upstream.status_code
            await upstream.aclose()
            await client.aclose()
            return Response(status_code=status, headers=out_headers, media_type=mime)

        async def body():
            try:
                async for chunk in upstream.aiter_raw():
                    yield chunk
            finally:
                await upstream.aclose()
                await client.aclose()

        return StreamingResponse(body(), status_code=upstream.status_code,
                                 headers=out_headers, media_type=mime)
    except HTTPException:
        if upstream:
            await upstream.aclose()
        await client.aclose()
        raise
    except (httpx.HTTPError, ValueError):
        if upstream:
            await upstream.aclose()
        await client.aclose()
        raise HTTPException(status_code=502, detail="连接视频 CDN 失败")

@app.post("/api/refresh")
async def refresh(request: Request):
    authorize(request)
    engine.items.clear()
    engine.ids.clear()
    engine.public_attempted.clear()
    await engine.navigate()
    return {"status": engine.status, "items": len(engine.items)}

class BrowserTap(BaseModel):
    x: float = Field(ge=0, le=VIEWPORT_WIDTH)
    y: float = Field(ge=0, le=VIEWPORT_HEIGHT)

class BrowserScroll(BaseModel):
    dy: int = Field(ge=-1200, le=1200)

async def browser_page():
    if engine.page is None:
        raise HTTPException(status_code=503, detail="Cloud browser is not running")
    return engine.page

@app.get("/api/browser/frame")
async def browser_frame(request: Request):
    """A JPEG of the REAL remote Chromium viewport; iOS 8 needs no JS/WebKit."""
    authorize(request)
    page = await browser_page()
    try:
        async with engine.navigation_lock:
            pixels = await page.screenshot(type="jpeg", quality=45, scale="css", timeout=10000)
        return Response(
            content=pixels, media_type="image/jpeg",
            headers={"Cache-Control": "private, no-store, max-age=0",
                     "X-Viewport-Width": str(VIEWPORT_WIDTH),
                     "X-Viewport-Height": str(VIEWPORT_HEIGHT)},
        )
    except Exception:
        raise HTTPException(status_code=503, detail="Screenshot temporarily unavailable")

@app.post("/api/browser/tap")
async def browser_tap(request: Request, point: BrowserTap):
    authorize(request)
    page = await browser_page()
    async with engine.navigation_lock:
        try:
            await page.mouse.click(point.x, point.y, delay=80)
        except Exception:
            raise HTTPException(status_code=503, detail="Browser could not process the tap")
    return {"ok": True}

@app.post("/api/browser/scroll")
async def browser_scroll(request: Request, scroll: BrowserScroll):
    authorize(request)
    page = await browser_page()
    async with engine.navigation_lock:
        try:
            await page.mouse.wheel(0, scroll.dy)
        except Exception:
            raise HTTPException(status_code=503, detail="Browser could not scroll")
    return {"ok": True}

@app.post("/api/browser/home")
async def browser_home(request: Request):
    authorize(request)
    await browser_page()
    await engine.navigate()
    return {"ok": True, "status": engine.status}

@app.post("/api/browser/back")
async def browser_back(request: Request):
    authorize(request)
    page = await browser_page()
    async with engine.navigation_lock:
        try:
            await page.go_back(wait_until="domcontentloaded", timeout=12000)
        except Exception:
            raise HTTPException(status_code=503, detail="Browser could not navigate back")
    return {"ok": True}


@app.post("/api/browser/stream/start")
async def start_browser_stream(request: Request):
    authorize(request)
    await browser_page()
    try:
        ticket = await cloud_stream.start()
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    return {"url": str(request.url_for("stream_playlist")) + "?ticket=" + ticket,
            "audio": cloud_stream.audio_enabled,
            "description": "云端浏览器实时 H264 视频，音频取决于服务端采集状态"}

@app.get("/api/browser/stream/index.m3u8", name="stream_playlist")
async def stream_playlist(ticket: str = ""):
    if not cloud_stream.authorized(ticket):
        raise HTTPException(status_code=403, detail="Stream expired")
    path = cloud_stream.root / "index.m3u8"
    if not path.is_file():
        raise HTTPException(status_code=503, detail="Playlist not ready")
    cloud_stream.touch()
    return Response(content=playlist_with_ticket(path.read_text(), ticket),
                    media_type="application/vnd.apple.mpegurl",
                    headers={"Cache-Control": "no-store"})

@app.get("/api/browser/stream/{filename}")
async def stream_segment(filename: str, ticket: str = ""):
    if not cloud_stream.authorized(ticket) or not valid_segment(filename):
        raise HTTPException(status_code=403, detail="Stream access denied")
    path = cloud_stream.root / filename
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Segment expired")
    cloud_stream.touch()
    return FileResponse(str(path), media_type="video/mp2t",
                        headers={"Cache-Control": "no-store"})

@app.post("/api/browser/stream/stop")
async def stop_browser_stream(request: Request):
    authorize(request)
    await cloud_stream.stop()
    return {"ok": True}
